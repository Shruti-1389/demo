import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import StatCard from "@/components/dashboard/StatCard";
import ContractChart from "@/components/dashboard/ContractChart";
import ActivityList from "@/components/dashboard/ActivityList";
import { Button } from "@/components/ui/button";
import { 
  Download, 
  Calendar, 
  ChevronDown, 
  Search, 
  Plus,
  FileText,
  Eye,
  Edit,
  MoreVertical
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { format } from "date-fns";
import { Contract } from "@shared/schema";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
} from "@/components/ui/dropdown-menu";

export default function Dashboard() {
  const { user } = useAuth();
  const [timePeriod, setTimePeriod] = useState<"last30days" | "last90days" | "thisyear">("last30days");

  // Fetch dashboard stats
  const { data: stats, isLoading: isLoadingStats } = useQuery({
    queryKey: ['/api/dashboard/stats'],
  });

  // Fetch recent contracts for table
  const { data: contracts, isLoading: isLoadingContracts } = useQuery<Contract[]>({
    queryKey: ['/api/contracts'],
  });

  // Format date for display
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "-";
    return format(new Date(dateString), "MMM d, yyyy");
  };

  // Recent contracts (limit to 4)
  const recentContracts = contracts?.slice(0, 4) || [];

  // Get greeting based on time of day
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return "Good morning";
    if (hour < 18) return "Good afternoon";
    return "Good evening";
  };

  return (
    <div>
      <div className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-2xl font-inter font-bold mb-2">
              {getGreeting()}, {user?.firstName || user?.email?.split('@')[0] || 'there'}!
            </h1>
            <p className="text-gray-500">
              Here's an overview of your contract management activity
            </p>
          </div>
          <div className="flex space-x-2 mt-4 md:mt-0">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  {timePeriod === "last30days" && "Last 30 days"}
                  {timePeriod === "last90days" && "Last 90 days"}
                  {timePeriod === "thisyear" && "This year"}
                  <ChevronDown className="h-4 w-4 ml-2" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setTimePeriod("last30days")}>
                  Last 30 days
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTimePeriod("last90days")}>
                  Last 90 days
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => setTimePeriod("thisyear")}>
                  This year
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {isLoadingStats ? (
            <>
              <Skeleton className="h-40" />
              <Skeleton className="h-40" />
              <Skeleton className="h-40" />
              <Skeleton className="h-40" />
            </>
          ) : (
            <>
              <StatCard
                title="Total Contracts"
                value={stats?.total || 0}
                type="total"
                changeValue={12}
              />
              <StatCard
                title="Active Contracts"
                value={stats?.active || 0}
                type="active"
                changeValue={8}
              />
              <StatCard
                title="Pending Signature"
                value={stats?.pending || 0}
                type="pending"
                changeValue={4}
              />
              <StatCard
                title="Expiring Soon"
                value={stats?.expiring || 0}
                type="expiring"
                changeText={`${stats?.expiring || 0} in next 30 days`}
              />
            </>
          )}
        </div>

        {/* Chart and Recent Activity */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Contract Chart */}
          <div className="lg:col-span-2">
            <ContractChart />
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-lg shadow-sm p-6 card-hover">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-lg font-inter font-semibold">Recent Activity</h2>
              <Button variant="link" size="sm" className="text-primary">
                View All
              </Button>
            </div>

            <ActivityList />
          </div>
        </div>
      </div>

      {/* Recent Contracts Table */}
      <div className="bg-white rounded-lg shadow-sm p-6 card-hover">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <h2 className="text-lg font-inter font-semibold mb-4 md:mb-0">Recent Contracts</h2>

          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <input
                type="text"
                placeholder="Search contracts..."
                className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-primary focus:border-primary w-full sm:w-64"
              />
            </div>

            <Link href="/contracts">
              <Button className="bg-primary hover:bg-primary/90">
                <Plus className="mr-2 h-4 w-4" />
                New Contract
              </Button>
            </Link>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[40px]">
                  <Checkbox />
                </TableHead>
                <TableHead>Contract Name</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Created</TableHead>
                <TableHead>Expires</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoadingContracts ? (
                Array(4).fill(0).map((_, index) => (
                  <TableRow key={index}>
                    <TableCell><Skeleton className="h-4 w-4" /></TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <Skeleton className="h-10 w-10 rounded-lg mr-4" />
                        <div>
                          <Skeleton className="h-4 w-40 mb-1" />
                          <Skeleton className="h-3 w-20" />
                        </div>
                      </div>
                    </TableCell>
                    <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-5 w-16 rounded-full" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell className="text-right"><Skeleton className="h-8 w-20 ml-auto" /></TableCell>
                  </TableRow>
                ))
              ) : recentContracts.length > 0 ? (
                recentContracts.map((contract) => (
                  <TableRow key={contract.id}>
                    <TableCell>
                      <Checkbox />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center">
                          <FileText className="text-primary h-5 w-5" />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-foreground">{contract.name}</div>
                          <div className="text-xs text-gray-500">{contract.parties || 'No parties specified'}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">{contract.type.charAt(0).toUpperCase() + contract.type.slice(1)}</div>
                    </TableCell>
                    <TableCell>
                      <span className={`status-badge ${contract.status}`}>
                        {contract.status.charAt(0).toUpperCase() + contract.status.slice(1)}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm text-gray-500">
                      {formatDate(contract.createdAt as string)}
                    </TableCell>
                    <TableCell className="text-sm text-gray-500">
                      {formatDate(contract.endDate as string)}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Link href={`/contracts/${contract.id}`}>
                          <Button variant="ghost" size="icon">
                            <Eye className="h-4 w-4 text-primary" />
                          </Button>
                        </Link>
                        <Link href={`/contracts/${contract.id}?edit=true`}>
                          <Button variant="ghost" size="icon">
                            <Edit className="h-4 w-4 text-gray-600" />
                          </Button>
                        </Link>
                        <Button variant="ghost" size="icon">
                          <MoreVertical className="h-4 w-4 text-gray-600" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8">
                    <div>
                      <p className="text-gray-500">No contracts found</p>
                      <Link href="/contracts">
                        <Button variant="link" className="mt-2 text-primary">
                          Create your first contract
                        </Button>
                      </Link>
                    </div>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>

        {recentContracts.length > 0 && (
          <div className="flex justify-center mt-6">
            <Link href="/contracts">
              <Button variant="outline">View All Contracts</Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
