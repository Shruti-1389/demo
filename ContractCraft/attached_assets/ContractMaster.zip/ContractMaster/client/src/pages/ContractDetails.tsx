import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Contract, Activity } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { format } from "date-fns";
import {
  Calendar,
  Download,
  Edit,
  FileText,
  ArrowLeft,
  Trash2,
  Clock,
  Users,
  Info,
  Check,
  Send,
  Loader2,
  AlertTriangle
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import ContractForm from "@/components/contracts/ContractForm";

interface ContractDetailsProps {
  id: string;
}

export default function ContractDetails({ id }: ContractDetailsProps) {
  const [, navigate] = useLocation();
  const [, params] = useRoute("/contracts/:id");
  const { toast } = useToast();
  const [isEditMode, setIsEditMode] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("details");

  // Get query parameters
  const queryParams = new URLSearchParams(window.location.search);
  const editParam = queryParams.get("edit");

  // Set edit mode if edit=true is in URL
  useEffect(() => {
    if (editParam === "true") {
      setIsEditMode(true);
    }
  }, [editParam]);

  // Fetch contract details
  const { 
    data: contract, 
    isLoading,
    error 
  } = useQuery<Contract>({
    queryKey: [`/api/contracts/${id}`],
  });

  // Fetch contract activities
  const { 
    data: activities, 
    isLoading: isLoadingActivities 
  } = useQuery<Activity[]>({
    queryKey: [`/api/contracts/${id}/activities`],
    enabled: !!contract,
  });

  // Delete contract mutation
  const deleteMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('DELETE', `/api/contracts/${id}`);
    },
    onSuccess: () => {
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ['/api/contracts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      
      toast({
        title: "Contract deleted",
        description: "The contract has been successfully deleted.",
        variant: "default",
      });
      
      // Navigate back to contracts page
      navigate("/contracts");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete contract: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Format date for display
  const formatDate = (dateString: string | null) => {
    if (!dateString) return "Not specified";
    return format(new Date(dateString), "MMMM d, yyyy");
  };

  // Handle delete confirmation
  const handleDelete = () => {
    setDeleteDialogOpen(false);
    deleteMutation.mutate();
  };

  // Handle edit mode toggle
  const handleEditModeToggle = () => {
    setIsEditMode(!isEditMode);
    
    // Update URL without edit=true when exiting edit mode
    if (isEditMode) {
      navigate(`/contracts/${id}`);
    } else {
      navigate(`/contracts/${id}?edit=true`);
    }
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  // Error state
  if (error || !contract) {
    return (
      <div className="bg-white rounded-lg shadow-sm p-8 text-center">
        <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
        <h2 className="text-xl font-medium mb-2">Contract Not Found</h2>
        <p className="text-gray-500 mb-6">The contract you're looking for doesn't exist or you don't have permission to view it.</p>
        <Button onClick={() => navigate("/contracts")}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Contracts
        </Button>
      </div>
    );
  }

  return (
    <div>
      {/* Back button and actions */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div className="flex items-center mb-4 md:mb-0">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={() => navigate("/contracts")}
            className="mr-4"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back
          </Button>
          <div>
            <h1 className="text-2xl font-inter font-bold">{contract.name}</h1>
            <div className="flex items-center mt-1">
              <Badge variant="outline" className="mr-2">
                {contract.type.charAt(0).toUpperCase() + contract.type.slice(1)}
              </Badge>
              <span className={`status-badge ${contract.status}`}>
                {contract.status.charAt(0).toUpperCase() + contract.status.slice(1)}
              </span>
            </div>
          </div>
        </div>
        <div className="flex space-x-2">
          <Button 
            variant="outline" 
            onClick={() => {
              // Download/export contract logic would go here
              toast({
                title: "Contract exported",
                description: "The contract has been exported as PDF.",
              });
            }}
          >
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
          {!isEditMode && (
            <Button 
              variant="outline" 
              onClick={handleEditModeToggle}
            >
              <Edit className="mr-2 h-4 w-4" />
              Edit
            </Button>
          )}
          <Button 
            variant="destructive" 
            onClick={() => setDeleteDialogOpen(true)}
          >
            <Trash2 className="mr-2 h-4 w-4" />
            Delete
          </Button>
        </div>
      </div>

      {isEditMode ? (
        <Card>
          <CardHeader>
            <CardTitle>Edit Contract</CardTitle>
            <CardDescription>Make changes to your contract details below</CardDescription>
          </CardHeader>
          <CardContent>
            <ContractForm 
              contractId={parseInt(id)} 
              onSuccess={handleEditModeToggle}
              onCancel={handleEditModeToggle}
            />
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Contract details */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
                  <TabsList>
                    <TabsTrigger value="details">Details</TabsTrigger>
                    <TabsTrigger value="content">Content</TabsTrigger>
                    <TabsTrigger value="activity">Activity</TabsTrigger>
                  </TabsList>
                </Tabs>
              </CardHeader>
              <CardContent>
                <TabsContent value="details" className="space-y-6">
                  {contract.description && (
                    <div>
                      <h3 className="text-lg font-medium mb-2">Description</h3>
                      <p className="text-gray-700">{contract.description}</p>
                      <Separator className="my-4" />
                    </div>
                  )}
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="text-sm font-medium text-gray-500 mb-1">Contract Period</h3>
                      <div className="flex items-center">
                        <Calendar className="mr-2 h-4 w-4 text-gray-400" />
                        <span>{formatDate(contract.startDate as string)} - {formatDate(contract.endDate as string)}</span>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium text-gray-500 mb-1">Status</h3>
                      <div className="flex items-center">
                        <Clock className="mr-2 h-4 w-4 text-gray-400" />
                        <span className={`status-badge ${contract.status}`}>
                          {contract.status.charAt(0).toUpperCase() + contract.status.slice(1)}
                        </span>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium text-gray-500 mb-1">Parties Involved</h3>
                      <div className="flex items-center">
                        <Users className="mr-2 h-4 w-4 text-gray-400" />
                        <span>{contract.parties || "Not specified"}</span>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-sm font-medium text-gray-500 mb-1">Created</h3>
                      <div className="flex items-center">
                        <Info className="mr-2 h-4 w-4 text-gray-400" />
                        <span>{formatDate(contract.createdAt as string)}</span>
                      </div>
                    </div>
                  </div>
                  
                  {contract.reminderEnabled && (
                    <>
                      <Separator className="my-4" />
                      <div className="flex items-center bg-primary/10 p-3 rounded-md">
                        <Check className="h-5 w-5 text-primary mr-2" />
                        <span>Renewal reminders are enabled for this contract</span>
                      </div>
                    </>
                  )}
                </TabsContent>
                
                <TabsContent value="content">
                  <div className="border rounded-md p-4 bg-gray-50 whitespace-pre-wrap min-h-[400px]">
                    {contract.content || (
                      <div className="text-center text-gray-500 py-12">
                        <FileText className="h-12 w-12 mx-auto mb-2 opacity-30" />
                        <p>No content available for this contract</p>
                      </div>
                    )}
                  </div>
                  
                  {contract.filePath && (
                    <div className="mt-4 flex justify-end">
                      <Button variant="outline" className="flex items-center">
                        <Download className="mr-2 h-4 w-4" />
                        Download Original File
                      </Button>
                    </div>
                  )}
                </TabsContent>
                
                <TabsContent value="activity">
                  <div className="space-y-4">
                    {isLoadingActivities ? (
                      Array(3).fill(0).map((_, index) => (
                        <div key={index} className="flex items-start animate-pulse">
                          <div className="w-8 h-8 bg-gray-200 rounded-full mr-3"></div>
                          <div className="flex-1">
                            <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                            <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                          </div>
                        </div>
                      ))
                    ) : activities && activities.length > 0 ? (
                      activities.map((activity) => {
                        // Activity icon based on type
                        let ActivityIcon;
                        let iconColor;
                        
                        switch (activity.type) {
                          case "create":
                            ActivityIcon = FileText;
                            iconColor = "text-primary";
                            break;
                          case "update":
                            ActivityIcon = Edit;
                            iconColor = "text-primary";
                            break;
                          case "sign":
                            ActivityIcon = Check;
                            iconColor = "text-success";
                            break;
                          case "send":
                            ActivityIcon = Send;
                            iconColor = "text-warning";
                            break;
                          case "delete":
                            ActivityIcon = Trash2;
                            iconColor = "text-destructive";
                            break;
                          default:
                            ActivityIcon = Info;
                            iconColor = "text-gray-500";
                        }
                        
                        return (
                          <div key={activity.id} className="flex items-start">
                            <div className={`w-8 h-8 rounded-full bg-${iconColor.split('-')[1]}-100 flex items-center justify-center mr-3 mt-1`}>
                              <ActivityIcon className={`${iconColor} text-sm`} />
                            </div>
                            <div>
                              <p className="text-sm font-medium">{activity.description}</p>
                              <p className="text-xs text-gray-500">
                                {format(new Date(activity.createdAt), "MMM d, yyyy 'at' h:mm a")}
                              </p>
                            </div>
                          </div>
                        );
                      })
                    ) : (
                      <div className="text-center text-gray-500 py-12">
                        <Info className="h-12 w-12 mx-auto mb-2 opacity-30" />
                        <p>No activity recorded for this contract</p>
                      </div>
                    )}
                  </div>
                </TabsContent>
              </CardContent>
              <CardFooter className="flex justify-end">
                {contract.status === "draft" && (
                  <Button 
                    className="bg-primary hover:bg-primary/90"
                    onClick={() => {
                      // Logic to send the contract for signature would go here
                      toast({
                        title: "Contract sent",
                        description: "The contract has been sent for signature.",
                      });
                    }}
                  >
                    <Send className="mr-2 h-4 w-4" />
                    Send for Signature
                  </Button>
                )}
              </CardFooter>
            </Card>
          </div>
          
          {/* Sidebar with additional details */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Contract Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-1">Contract ID</h3>
                  <p>#{contract.id}</p>
                </div>
                
                {contract.templateId && (
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Template</h3>
                    <p>Template #{contract.templateId}</p>
                  </div>
                )}
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-1">Created</h3>
                  <p>{formatDate(contract.createdAt as string)}</p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-1">Last Updated</h3>
                  <p>{formatDate(contract.updatedAt as string)}</p>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-1">Duration</h3>
                  <p>
                    {(() => {
                      if (!contract.startDate || !contract.endDate) return "Not specified";
                      
                      const start = new Date(contract.startDate);
                      const end = new Date(contract.endDate);
                      const days = Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
                      
                      if (days < 30) return `${days} days`;
                      if (days < 365) {
                        const months = Math.round(days / 30);
                        return `${months} month${months > 1 ? 's' : ''}`;
                      }
                      
                      const years = Math.round(days / 365 * 10) / 10;
                      return `${years} year${years !== 1 ? 's' : ''}`;
                    })()}
                  </p>
                </div>
                
                <div>
                  <h3 className="text-sm font-medium text-gray-500 mb-1">Time Remaining</h3>
                  <p>
                    {(() => {
                      if (!contract.endDate) return "Not specified";
                      if (contract.status === "expired") return "Expired";
                      
                      const now = new Date();
                      const end = new Date(contract.endDate);
                      
                      if (end < now) return "Expired";
                      
                      const days = Math.round((end.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
                      
                      if (days < 30) return `${days} days remaining`;
                      if (days < 365) {
                        const months = Math.round(days / 30);
                        return `${months} month${months > 1 ? 's' : ''} remaining`;
                      }
                      
                      const years = Math.round(days / 365 * 10) / 10;
                      return `${years} year${years !== 1 ? 's' : ''} remaining`;
                    })()}
                  </p>
                </div>
              </CardContent>
            </Card>
            
            {/* Quick Actions Card */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button 
                  variant="outline" 
                  className="w-full justify-start" 
                  onClick={() => {
                    // Export logic
                    toast({
                      title: "Contract exported",
                      description: "The contract has been exported as PDF.",
                    });
                  }}
                >
                  <Download className="mr-2 h-4 w-4" />
                  Export as PDF
                </Button>
                
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => handleEditModeToggle()}
                >
                  <Edit className="mr-2 h-4 w-4" />
                  Edit Contract
                </Button>
                
                {contract.status === "draft" && (
                  <Button 
                    className="w-full justify-start bg-primary hover:bg-primary/90"
                    onClick={() => {
                      // Send for signature logic
                      toast({
                        title: "Contract sent",
                        description: "The contract has been sent for signature.",
                      });
                    }}
                  >
                    <Send className="mr-2 h-4 w-4" />
                    Send for Signature
                  </Button>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Delete confirmation dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the contract
              and all associated data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground"
            >
              {deleteMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : (
                <>Delete</>
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
