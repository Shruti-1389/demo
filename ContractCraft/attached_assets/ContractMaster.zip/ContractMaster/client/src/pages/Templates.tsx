import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Template, InsertContract } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Plus, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import TemplateCard from "@/components/templates/TemplateCard";
import TemplateForm from "@/components/templates/TemplateForm";
import ContractForm from "@/components/contracts/ContractForm";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";

export default function Templates() {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [createFormOpen, setCreateFormOpen] = useState(false);
  const [editFormOpen, setEditFormOpen] = useState(false);
  const [viewFormOpen, setViewFormOpen] = useState(false);
  const [createContractOpen, setCreateContractOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [activeTab, setActiveTab] = useState("my-templates");

  // Fetch templates
  const { data: templatesData, isLoading } = useQuery({
    queryKey: ['/api/templates'],
  });

  const myTemplates = templatesData?.userTemplates || [];
  const publicTemplates = templatesData?.publicTemplates || [];

  // Filtered templates based on search query
  const filteredMyTemplates = myTemplates.filter(template => 
    template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    template.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (template.description && template.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  const filteredPublicTemplates = publicTemplates.filter(template => 
    template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    template.type.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (template.description && template.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  // Handle template view
  const handleViewTemplate = (template: Template) => {
    setSelectedTemplate(template);
    setViewFormOpen(true);
  };

  // Handle template edit
  const handleEditTemplate = (template: Template) => {
    setSelectedTemplate(template);
    setEditFormOpen(true);
  };

  // Handle template delete
  const handleDeleteTemplate = async (templateId: number) => {
    try {
      await apiRequest('DELETE', `/api/templates/${templateId}`);
      
      // Invalidate cache to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/templates'] });
      
      toast({
        title: "Template deleted",
        description: "The template has been successfully deleted.",
        variant: "default",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete the template. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Handle use template to create contract
  const handleUseTemplate = (template: Template) => {
    setSelectedTemplate(template);
    setCreateContractOpen(true);
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-inter font-bold mb-2">Templates</h1>
          <p className="text-gray-500">Create and manage standardized contract templates</p>
        </div>
        <div className="flex space-x-2 mt-4 md:mt-0">
          <Button 
            onClick={() => setCreateFormOpen(true)} 
            className="bg-primary hover:bg-primary/90"
          >
            <Plus className="mr-2 h-4 w-4" />
            New Template
          </Button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
        <div className="flex flex-col md:flex-row justify-between mb-6">
          <Tabs defaultValue={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="mb-4">
              <TabsTrigger value="my-templates">My Templates</TabsTrigger>
              <TabsTrigger value="public-templates">Public Templates</TabsTrigger>
            </TabsList>

            <div className="flex justify-end mb-4">
              <div className="relative max-w-sm">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input 
                  placeholder="Search templates..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <TabsContent value="my-templates">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {isLoading ? (
                  Array(3).fill(0).map((_, index) => (
                    <div key={index} className="h-72">
                      <div className="bg-white rounded-lg shadow-sm p-6 h-full animate-pulse">
                        <div className="flex justify-between items-start mb-3">
                          <div className="h-10 w-10 bg-gray-200 rounded-lg"></div>
                          <div className="h-5 w-16 bg-gray-200 rounded-full"></div>
                        </div>
                        <div className="h-5 w-40 bg-gray-200 mb-2"></div>
                        <div className="h-3 w-full bg-gray-200 mb-1"></div>
                        <div className="h-3 w-3/4 bg-gray-200 mb-4"></div>
                        
                        <div className="space-y-2 mt-auto">
                          <div className="h-4 w-full bg-gray-200"></div>
                          <div className="h-4 w-full bg-gray-200"></div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : filteredMyTemplates.length > 0 ? (
                  filteredMyTemplates.map((template) => (
                    <TemplateCard 
                      key={template.id} 
                      template={template}
                      onView={handleViewTemplate}
                      onEdit={handleEditTemplate}
                      onDelete={handleDeleteTemplate}
                      onUseTemplate={handleUseTemplate}
                    />
                  ))
                ) : (
                  <div className="col-span-full flex flex-col items-center justify-center p-8">
                    <div className="text-center">
                      {searchQuery ? (
                        <>
                          <h3 className="text-lg font-medium mb-2">No templates found</h3>
                          <p className="text-gray-500 mb-4">No templates match your search: "{searchQuery}"</p>
                          <Button variant="outline" onClick={() => setSearchQuery("")}>
                            Clear Search
                          </Button>
                        </>
                      ) : (
                        <>
                          <h3 className="text-lg font-medium mb-2">No templates found</h3>
                          <p className="text-gray-500 mb-4">Create your first template to get started</p>
                          <Button 
                            onClick={() => setCreateFormOpen(true)} 
                            className="bg-primary hover:bg-primary/90"
                          >
                            <Plus className="mr-2 h-4 w-4" />
                            New Template
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
            
            <TabsContent value="public-templates">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {isLoading ? (
                  Array(3).fill(0).map((_, index) => (
                    <div key={index} className="h-72">
                      <div className="bg-white rounded-lg shadow-sm p-6 h-full animate-pulse">
                        <div className="flex justify-between items-start mb-3">
                          <div className="h-10 w-10 bg-gray-200 rounded-lg"></div>
                          <div className="h-5 w-16 bg-gray-200 rounded-full"></div>
                        </div>
                        <div className="h-5 w-40 bg-gray-200 mb-2"></div>
                        <div className="h-3 w-full bg-gray-200 mb-1"></div>
                        <div className="h-3 w-3/4 bg-gray-200 mb-4"></div>
                        
                        <div className="space-y-2 mt-auto">
                          <div className="h-4 w-full bg-gray-200"></div>
                          <div className="h-4 w-full bg-gray-200"></div>
                        </div>
                      </div>
                    </div>
                  ))
                ) : filteredPublicTemplates.length > 0 ? (
                  filteredPublicTemplates.map((template) => (
                    <TemplateCard 
                      key={template.id} 
                      template={template}
                      onView={handleViewTemplate}
                      onUseTemplate={handleUseTemplate}
                    />
                  ))
                ) : (
                  <div className="col-span-full flex flex-col items-center justify-center p-8">
                    <div className="text-center">
                      {searchQuery ? (
                        <>
                          <h3 className="text-lg font-medium mb-2">No public templates found</h3>
                          <p className="text-gray-500 mb-4">No public templates match your search: "{searchQuery}"</p>
                          <Button variant="outline" onClick={() => setSearchQuery("")}>
                            Clear Search
                          </Button>
                        </>
                      ) : (
                        <>
                          <h3 className="text-lg font-medium mb-2">No public templates available</h3>
                          <p className="text-gray-500 mb-4">Public templates will appear here when they are shared</p>
                        </>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Create Template Dialog */}
      <Dialog open={createFormOpen} onOpenChange={setCreateFormOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Template</DialogTitle>
            <DialogDescription>
              Fill out the form below to create a new contract template.
            </DialogDescription>
          </DialogHeader>
          <TemplateForm 
            onSuccess={() => setCreateFormOpen(false)}
            onCancel={() => setCreateFormOpen(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Template Dialog */}
      <Dialog open={editFormOpen} onOpenChange={setEditFormOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Template</DialogTitle>
            <DialogDescription>
              Update your template details below.
            </DialogDescription>
          </DialogHeader>
          {selectedTemplate && (
            <TemplateForm 
              templateId={selectedTemplate.id}
              onSuccess={() => setEditFormOpen(false)}
              onCancel={() => setEditFormOpen(false)}
            />
          )}
        </DialogContent>
      </Dialog>

      {/* View Template Dialog */}
      <Dialog open={viewFormOpen} onOpenChange={setViewFormOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedTemplate?.name}</DialogTitle>
            <DialogDescription>
              Template Details
            </DialogDescription>
          </DialogHeader>
          {selectedTemplate && (
            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-500">Type</h3>
                <p>{selectedTemplate.type.charAt(0).toUpperCase() + selectedTemplate.type.slice(1)}</p>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Description</h3>
                <p>{selectedTemplate.description || "No description provided"}</p>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-500">Content</h3>
                <div className="p-4 border rounded-md bg-gray-50 whitespace-pre-wrap">
                  {selectedTemplate.content}
                </div>
              </div>
              
              <div className="flex justify-end space-x-3 pt-4">
                <Button variant="outline" onClick={() => setViewFormOpen(false)}>
                  Close
                </Button>
                <Button 
                  className="bg-primary hover:bg-primary/90"
                  onClick={() => {
                    setViewFormOpen(false);
                    handleUseTemplate(selectedTemplate);
                  }}
                >
                  Use Template
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create Contract From Template Dialog */}
      <Dialog open={createContractOpen} onOpenChange={setCreateContractOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create Contract from Template</DialogTitle>
            <DialogDescription>
              Create a new contract using the {selectedTemplate?.name} template.
            </DialogDescription>
          </DialogHeader>
          <ContractForm 
            onSuccess={() => setCreateContractOpen(false)}
            onCancel={() => setCreateContractOpen(false)}
          />
        </DialogContent>
      </Dialog>
    </div>
  );
}
