import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Contract } from "@shared/schema";
import ReportCard from "@/components/reports/ReportCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Download, ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Reports() {
  const [timePeriod, setTimePeriod] = useState<"last30days" | "last90days" | "thisyear">("last30days");
  
  // Fetch contracts for reports
  const { data: contracts, isLoading } = useQuery<Contract[]>({
    queryKey: ['/api/contracts'],
  });

  // Function to calculate contract statistics
  const calculateContractStats = () => {
    if (!contracts) return {
      byType: [],
      byStatus: [],
      byMonth: []
    };

    // Count by type
    const typeCount: Record<string, number> = {};
    contracts.forEach(contract => {
      typeCount[contract.type] = (typeCount[contract.type] || 0) + 1;
    });

    // Count by status
    const statusCount: Record<string, number> = {};
    contracts.forEach(contract => {
      statusCount[contract.status] = (statusCount[contract.status] || 0) + 1;
    });

    // Count by month
    const monthCount: Record<string, number> = {};
    const now = new Date();
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    
    // Initialize all months with 0
    for (let i = 5; i >= 0; i--) {
      const month = new Date(now.getFullYear(), now.getMonth() - i, 1);
      monthCount[monthNames[month.getMonth()]] = 0;
    }
    
    // Count contracts by creation month
    contracts.forEach(contract => {
      const createdAt = new Date(contract.createdAt as string);
      const monthName = monthNames[createdAt.getMonth()];
      
      // Only count if it's within the last 6 months
      const monthDiff = (now.getFullYear() - createdAt.getFullYear()) * 12 + now.getMonth() - createdAt.getMonth();
      if (monthDiff >= 0 && monthDiff < 6) {
        monthCount[monthName] = (monthCount[monthName] || 0) + 1;
      }
    });

    // Colors for charts
    const colors = {
      service: "hsl(var(--primary))",
      nda: "hsl(var(--secondary))",
      employment: "hsl(var(--warning))",
      vendor: "hsl(var(--destructive))",
      partnership: "hsl(var(--chart-5))",
      other: "hsl(var(--muted-foreground))",
      
      active: "hsl(var(--success))",
      pending: "hsl(var(--warning))",
      expired: "hsl(var(--destructive))",
      draft: "hsl(var(--muted-foreground))",
      terminated: "hsl(var(--chart-5))",
      archived: "hsl(var(--secondary))",
    };

    return {
      byType: Object.entries(typeCount).map(([name, value]) => ({
        name: name.charAt(0).toUpperCase() + name.slice(1),
        value,
        color: colors[name as keyof typeof colors] || "hsl(var(--muted-foreground))"
      })),
      byStatus: Object.entries(statusCount).map(([name, value]) => ({
        name: name.charAt(0).toUpperCase() + name.slice(1),
        value,
        color: colors[name as keyof typeof colors] || "hsl(var(--muted-foreground))"
      })),
      byMonth: Object.entries(monthCount).map(([name, value], index) => ({
        name,
        value,
        color: "hsl(var(--primary))"
      }))
    };
  };

  const stats = calculateContractStats();

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-inter font-bold mb-2">Reports</h1>
          <p className="text-gray-500">View analytics and insights about your contracts</p>
        </div>
        <div className="flex space-x-2 mt-4 md:mt-0">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="flex items-center">
                <Calendar className="h-4 w-4 mr-2" />
                {timePeriod === "last30days" && "Last 30 days"}
                {timePeriod === "last90days" && "Last 90 days"}
                {timePeriod === "thisyear" && "This year"}
                <ChevronDown className="h-4 w-4 ml-2" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setTimePeriod("last30days")}>
                Last 30 days
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTimePeriod("last90days")}>
                Last 90 days
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setTimePeriod("thisyear")}>
                This year
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          <Button variant="outline" className="flex items-center">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <ReportCard 
          title="Contracts by Type" 
          type="pie" 
          data={stats.byType}
        />
        <ReportCard 
          title="Contracts by Status" 
          type="pie" 
          data={stats.byStatus}
        />
      </div>

      <div className="mb-6">
        <Card className="card-hover">
          <CardHeader>
            <CardTitle>Contracts Created Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <ReportCard 
              title="" 
              type="bar" 
              data={stats.byMonth}
            />
          </CardContent>
        </Card>
      </div>

      {/* Summary Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="card-hover">
          <CardHeader>
            <CardTitle>Contract Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center border-b pb-2">
                <span className="font-medium">Total Contracts</span>
                <span className="text-lg">{contracts?.length || 0}</span>
              </div>
              <div className="flex justify-between items-center border-b pb-2">
                <span className="font-medium">Active Contracts</span>
                <span className="text-lg">{contracts?.filter(c => c.status === 'active').length || 0}</span>
              </div>
              <div className="flex justify-between items-center border-b pb-2">
                <span className="font-medium">Expiring Soon (30 days)</span>
                <span className="text-lg">
                  {contracts?.filter(c => {
                    if (c.status !== 'active' || !c.endDate) return false;
                    const endDate = new Date(c.endDate);
                    const now = new Date();
                    const thirtyDaysFromNow = new Date();
                    thirtyDaysFromNow.setDate(now.getDate() + 30);
                    return endDate <= thirtyDaysFromNow && endDate >= now;
                  }).length || 0}
                </span>
              </div>
              <div className="flex justify-between items-center border-b pb-2">
                <span className="font-medium">Average Contract Duration</span>
                <span className="text-lg">
                  {(() => {
                    if (!contracts || contracts.length === 0) return "N/A";
                    
                    let totalDays = 0;
                    let validContracts = 0;
                    
                    contracts.forEach(contract => {
                      if (contract.startDate && contract.endDate) {
                        const start = new Date(contract.startDate);
                        const end = new Date(contract.endDate);
                        const days = Math.round((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
                        if (days > 0) {
                          totalDays += days;
                          validContracts++;
                        }
                      }
                    });
                    
                    if (validContracts === 0) return "N/A";
                    const avgDays = Math.round(totalDays / validContracts);
                    return `${avgDays} days`;
                  })()}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-hover">
          <CardHeader>
            <CardTitle>Contract Status Breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <div key={i} className="flex items-center">
                    <div className="w-full bg-gray-200 rounded-full h-4 mr-2">
                      <div className="animate-pulse bg-gray-300 h-4 rounded-full" style={{ width: `${Math.random() * 100}%` }}></div>
                    </div>
                    <span className="text-sm font-medium text-gray-500 min-w-[40px] text-right">
                      {Math.floor(Math.random() * 100)}%
                    </span>
                  </div>
                ))
              ) : (
                stats.byStatus.map(status => {
                  const percentage = contracts?.length 
                    ? Math.round((status.value / contracts.length) * 100) 
                    : 0;
                  
                  return (
                    <div key={status.name} className="flex items-center">
                      <div className="flex-1 mr-4">
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">{status.name}</span>
                          <span className="text-sm text-gray-500">{status.value} contracts</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="h-2 rounded-full" 
                            style={{ 
                              width: `${percentage}%`,
                              backgroundColor: status.color
                            }}
                          ></div>
                        </div>
                      </div>
                      <span className="text-sm font-medium min-w-[40px] text-right">
                        {percentage}%
                      </span>
                    </div>
                  );
                })
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
