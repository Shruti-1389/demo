import { useState, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Contract } from "@shared/schema";
import ContractTable from "@/components/contracts/ContractTable";
import ContractForm from "@/components/contracts/ContractForm";
import { Button } from "@/components/ui/button";
import { Plus, Upload, FileText } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { ContractCard } from "@/components/contracts/ContractCard";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Contracts() {
  const { toast } = useToast();
  const [formOpen, setFormOpen] = useState(false);
  const [importDialogOpen, setImportDialogOpen] = useState(false);
  const [viewMode, setViewMode] = useState<"table" | "grid">("table");
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Fetch contracts
  const { data: contracts, isLoading } = useQuery<Contract[]>({
    queryKey: ['/api/contracts'],
  });

  // Contract import mutation
  const importMutation = useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch('/api/contracts/import', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || 'Failed to import contract');
      }
      
      return await response.json();
    },
    onSuccess: () => {
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/contracts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      
      setImportDialogOpen(false);
      
      toast({
        title: "Contract imported",
        description: "The contract has been successfully imported.",
        variant: "default",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Import failed",
        description: error.message || "Failed to import the contract. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Open/close dialogs
  const openNewContractForm = () => setFormOpen(true);
  const closeContractForm = () => setFormOpen(false);
  const openImportDialog = () => setImportDialogOpen(true);
  const closeImportDialog = () => setImportDialogOpen(false);

  // Handle file selection for import
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const file = e.target.files[0];
      const formData = new FormData();
      formData.append('file', file);
      importMutation.mutate(formData);
    }
  };

  // Handle contract deletion
  const handleDeleteContract = async (contractId: number) => {
    try {
      await apiRequest('DELETE', `/api/contracts/${contractId}`);
      
      // Invalidate cache to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/contracts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      
      toast({
        title: "Contract deleted",
        description: "The contract has been successfully deleted.",
        variant: "default",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete the contract. Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <div>
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <div>
          <h1 className="text-2xl font-inter font-bold mb-2">Contracts</h1>
          <p className="text-gray-500">Manage all your contracts in one place</p>
        </div>
        <div className="flex items-center space-x-2 mt-4 md:mt-0">
          <Tabs defaultValue={viewMode} onValueChange={(value) => setViewMode(value as "table" | "grid")} className="hidden md:flex">
            <TabsList>
              <TabsTrigger value="table">Table View</TabsTrigger>
              <TabsTrigger value="grid">Grid View</TabsTrigger>
            </TabsList>
          </Tabs>
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              className="border-primary text-primary"
              onClick={async () => {
                try {
                  const response = await fetch('/api/contracts/export', {
                    method: 'GET',
                  });
                  const blob = await response.blob();
                  const url = window.URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'contracts.xlsx';
                  a.click();
                } catch (error) {
                  toast({
                    title: "Export failed",
                    description: "Failed to export contracts",
                    variant: "destructive",
                  });
                }
              }}
            >
              <FileText className="mr-2 h-4 w-4" />
              Export
            </Button>
          </div>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            accept=".pdf,.doc,.docx"
            className="hidden"
          />
        </div>
      </div>

      {/* Table/Grid View */}
      {viewMode === "table" ? (
        <ContractTable 
          onNewContract={openNewContractForm}
          onImportContract={openImportDialog}
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array(6).fill(0).map((_, index) => (
              <div key={index} className="h-72">
                <div className="bg-white rounded-lg shadow-sm p-6 h-full animate-pulse">
                  <div className="flex justify-between items-start mb-3">
                    <div className="h-10 w-10 bg-gray-200 rounded-lg"></div>
                    <div className="h-5 w-16 bg-gray-200 rounded-full"></div>
                  </div>
                  <div className="h-5 w-40 bg-gray-200 mb-2"></div>
                  <div className="h-3 w-full bg-gray-200 mb-1"></div>
                  <div className="h-3 w-3/4 bg-gray-200 mb-4"></div>
                  
                  <div className="space-y-2 mt-auto">
                    <div className="h-4 w-full bg-gray-200"></div>
                    <div className="h-4 w-full bg-gray-200"></div>
                    <div className="h-4 w-full bg-gray-200"></div>
                  </div>
                </div>
              </div>
            ))
          ) : contracts && contracts.length > 0 ? (
            contracts.map((contract) => (
              <ContractCard 
                key={contract.id} 
                contract={contract}
                onDelete={handleDeleteContract}
              />
            ))
          ) : (
            <div className="col-span-full flex flex-col items-center justify-center p-8 bg-white rounded-lg shadow-sm">
              <div className="text-center">
                <h3 className="text-lg font-medium mb-2">No contracts found</h3>
                <p className="text-gray-500 mb-4">Create your first contract to get started</p>
                <Button onClick={openNewContractForm} className="bg-primary hover:bg-primary/90">
                  <Plus className="mr-2 h-4 w-4" />
                  New Contract
                </Button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* New Contract Dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Contract</DialogTitle>
            <DialogDescription>
              Fill out the form below to create a new contract.
            </DialogDescription>
          </DialogHeader>
          <ContractForm 
            onSuccess={() => {
              closeContractForm();
              // Refresh contracts and dashboard data
              queryClient.invalidateQueries({ queryKey: ['/api/contracts'] });
              queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
            }}
            onCancel={closeContractForm}
          />
        </DialogContent>
      </Dialog>
      
      {/* Import Contract Dialog */}
      <Dialog open={importDialogOpen} onOpenChange={setImportDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Import Contract</DialogTitle>
            <DialogDescription>
              Import an existing contract from PDF or Word document.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-center w-full">
              <label
                htmlFor="contract-file-upload"
                className="flex flex-col items-center justify-center w-full h-64 border-2 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 border-gray-300"
              >
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <Upload className="w-10 h-10 mb-3 text-gray-400" />
                  <p className="mb-2 text-sm text-gray-500">
                    <span className="font-semibold">Click to upload</span> or drag and drop
                  </p>
                  <p className="text-xs text-gray-500">PDF, DOC, or DOCX (Max 10MB)</p>
                </div>
                <input
                  id="contract-file-upload"
                  type="file"
                  className="hidden"
                  accept=".pdf,.doc,.docx"
                  onChange={handleFileSelect}
                />
              </label>
            </div>
            
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={closeImportDialog}>
                Cancel
              </Button>
              <Button 
                onClick={() => document.getElementById('contract-file-upload')?.click()} 
                className="bg-primary hover:bg-primary/90"
                disabled={importMutation.isPending}
              >
                {importMutation.isPending ? 'Importing...' : 'Select File'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
