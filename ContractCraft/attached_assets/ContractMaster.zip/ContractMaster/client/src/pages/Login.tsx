import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText } from "lucide-react";

export default function Login() {
  const [, navigate] = useLocation();
  const { isAuthenticated, isLoading } = useAuth();
  
  // Redirect to dashboard if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate("/");
    }
  }, [isAuthenticated, navigate]);
  
  // Handle login button click
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="max-w-md w-full">
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
              <FileText className="h-8 w-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold font-inter">ContractFlow</CardTitle>
            <CardDescription>
              Efficiently manage all your contracts in one place
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center space-y-2">
              <h2 className="text-xl font-medium font-inter">Welcome Back</h2>
              <p className="text-gray-500">Sign in to access your contract management dashboard</p>
            </div>
            
            <div className="space-y-2">
              <Button 
                className="w-full bg-primary hover:bg-primary/90 py-6"
                onClick={handleLogin}
              >
                Sign In
              </Button>
            </div>
          </CardContent>
          <CardFooter className="text-center text-sm text-gray-500">
            <p className="w-full">
              By signing in, you agree to our Terms of Service and Privacy Policy
            </p>
          </CardFooter>
        </Card>
        
        <div className="mt-8 text-center">
          <h3 className="text-lg font-medium mb-2">Why Use ContractFlow?</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <h4 className="font-medium text-primary mb-1">Centralized Management</h4>
              <p className="text-sm text-gray-500">Keep all your contracts organized in one secure place</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <h4 className="font-medium text-primary mb-1">Easy Templates</h4>
              <p className="text-sm text-gray-500">Create and reuse professional templates</p>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <h4 className="font-medium text-primary mb-1">Powerful Analytics</h4>
              <p className="text-sm text-gray-500">Track contract status and performance insights</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
