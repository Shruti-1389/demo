import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import Contracts from "@/pages/Contracts";
import Templates from "@/pages/Templates";
import Reports from "@/pages/Reports";
import Settings from "@/pages/Settings";
import Login from "@/pages/Login";
import Welcome from "@/pages/Welcome";
import ContractDetails from "@/pages/ContractDetails";
import AppShell from "@/components/layout/AppShell";
import { useAuth } from "@/hooks/useAuth";

function PrivateRoute({ component: Component, ...rest }: { component: React.ComponentType<any>, path: string }) {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return <div className="min-h-screen w-full flex items-center justify-center bg-background">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
    </div>;
  }
  
  if (!isAuthenticated) {
    window.location.href = "/api/login";
    return null;
  }
  
  return <Component {...rest} />;
}

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();
  
  // Show loading state while checking authentication
  if (isLoading) {
    return <div className="min-h-screen w-full flex items-center justify-center bg-background">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
    </div>;
  }
  
  // If authenticated but no user details yet, show welcome page
  const showWelcome = isAuthenticated && (!user?.firstName && !user?.lastName);
  
  return (
    <Switch>
      <Route path="/login">
        <Login />
      </Route>
      
      <Route path="/welcome">
        {isAuthenticated ? <Welcome /> : <Login />}
      </Route>
      
      <Route path="/">
        {isAuthenticated ? (
          showWelcome ? <Welcome /> : 
          <AppShell>
            <Dashboard />
          </AppShell>
        ) : <Login />}
      </Route>
      
      <Route path="/contracts">
        <PrivateRoute component={() => <AppShell><Contracts /></AppShell>} path="/contracts" />
      </Route>
      
      <Route path="/contracts/:id">
        {(params) => (
          <PrivateRoute component={() => <AppShell><ContractDetails id={params.id} /></AppShell>} path={`/contracts/${params.id}`} />
        )}
      </Route>
      
      <Route path="/templates">
        <PrivateRoute component={() => <AppShell><Templates /></AppShell>} path="/templates" />
      </Route>
      
      <Route path="/reports">
        <PrivateRoute component={() => <AppShell><Reports /></AppShell>} path="/reports" />
      </Route>
      
      <Route path="/settings">
        <PrivateRoute component={() => <AppShell><Settings /></AppShell>} path="/settings" />
      </Route>
      
      {/* Fallback to 404 */}
      <Route>
        <NotFound />
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Router>
          <Toaster />
        </Router>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;