import { useLocation } from "wouter";
import { Menu, Bell, HelpCircle, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { NavigationMenu, NavigationMenuList, NavigationMenuItem } from "@/components/ui/navigation-menu";
import { Link } from "wouter";

interface AppBarProps {
  toggleSidebar: () => void;
}

export default function AppBar({ toggleSidebar }: AppBarProps) {
  const [location] = useLocation();
  const isMobile = useIsMobile();

  return (
    <header className="bg-white shadow-sm h-16 flex items-center z-10 sticky top-0">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center">
          {isMobile && (
            <Button variant="ghost" size="icon" onClick={toggleSidebar} className="mr-4 md:hidden">
              <Menu className="h-6 w-6" />
            </Button>
          )}
          <NavigationMenu>
            <NavigationMenuList>
              <NavigationMenuItem>
                <Link href="/">
                  <a className={`px-4 py-2 text-sm font-medium ${location === "/" ? "text-primary" : "text-gray-600"}`}>
                    Dashboard
                  </a>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/contracts">
                  <a className={`px-4 py-2 text-sm font-medium ${location.startsWith("/contracts") ? "text-primary" : "text-gray-600"}`}>
                    Contracts
                  </a>
                </Link>
              </NavigationMenuItem>
              <NavigationMenuItem>
                <Link href="/reports">
                  <a className={`px-4 py-2 text-sm font-medium ${location === "/reports" ? "text-primary" : "text-gray-600"}`}>
                    Reports
                  </a>
                </Link>
              </NavigationMenuItem>
            </NavigationMenuList>
          </NavigationMenu>
        </div>
        <div className="flex items-center space-x-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                <span className="absolute top-1 right-1 w-2 h-2 bg-destructive rounded-full"></span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>No new notifications</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <HelpCircle className="h-5 w-5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Help Center</DropdownMenuItem>
              <DropdownMenuItem>Documentation</DropdownMenuItem>
              <DropdownMenuItem>Contact Support</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
          
          <a href="/api/logout">
            <Button variant="ghost" size="icon">
              <LogOut className="h-5 w-5" />
            </Button>
          </a>
        </div>
      </div>
    </header>
  );
}