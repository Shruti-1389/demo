import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { 
  Home, 
  FileText, 
  BarChart,
  LogOut,
  X 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useIsMobile } from "@/hooks/use-mobile";

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();
  const { user } = useAuth();
  const isMobile = useIsMobile();

  const navItems = [
    { icon: <Home className="mr-3 h-5 w-5" />, label: "Dashboard", path: "/" },
    { icon: <FileText className="mr-3 h-5 w-5" />, label: "Contracts", path: "/contracts" },
    { icon: <BarChart className="mr-3 h-5 w-5" />, label: "Reports", path: "/reports" },
  ];

  return (
    <aside className={`fixed inset-y-0 left-0 z-20 flex w-64 flex-col bg-gray-900 text-white transform transition-transform duration-200 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'} md:relative md:translate-x-0`}>
      <div className="p-4 flex flex-col h-full">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-xl font-bold">ContractFlow</h1>
          {isMobile && (
            <Button variant="ghost" size="icon" onClick={onClose} className="md:hidden text-white">
              <X className="h-6 w-6" />
            </Button>
          )}
        </div>

        <nav className="flex-1">
          <ul className="space-y-1">
            {navItems.map((item) => (
              <li key={item.path}>
                <Link href={item.path} className={`flex items-center px-4 py-2 text-sm rounded-lg hover:bg-gray-800 ${location === item.path ? 'bg-gray-800' : ''}`}>
                  {item.icon}
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="mt-auto pt-4 border-t border-gray-700">
          <Link href="/api/logout" className="flex items-center px-4 py-2 text-sm hover:bg-gray-800 rounded-lg">
            <LogOut className="mr-3 h-5 w-5" />
            Logout
          </Link>
        </div>
      </div>
    </aside>
  );
}