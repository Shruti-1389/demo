import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertContractSchema, contractTypeEnum, contractStatusEnum } from "@shared/schema";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { CalendarIcon, Loader2 } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

// Extend the insert schema with additional validation
const formSchema = insertContractSchema.extend({
  startDate: z.date().optional(),
  endDate: z.date().optional().refine(
    (date) => !date || (date instanceof Date && !isNaN(date.getTime())),
    { message: "Please enter a valid date" }
  ),
  sendForSignature: z.boolean().default(false),
  setReminders: z.boolean().default(false),
});

// Create a type for our form values
type FormValues = z.infer<typeof formSchema>;

interface ContractFormProps {
  contractId?: number;
  onSuccess?: () => void;
  onCancel?: () => void;
}

export default function ContractForm({ contractId, onSuccess, onCancel }: ContractFormProps) {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  
  // Fetch contract data if editing
  const { data: contract, isLoading: isLoadingContract } = useQuery({
    queryKey: contractId ? [`/api/contracts/${contractId}`] : null,
    enabled: !!contractId,
  });
  
  // Fetch templates for dropdown
  const { data: templatesData } = useQuery({
    queryKey: ['/api/templates'],
  });
  
  const templates = templatesData?.userTemplates || [];
  
  // Create form with react-hook-form
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: contract?.name || "",
      type: contract?.type || "service",
      status: contract?.status || "draft",
      description: contract?.description || "",
      parties: contract?.parties || "",
      templateId: contract?.templateId || undefined,
      content: contract?.content || "",
      startDate: contract?.startDate ? new Date(contract.startDate) : undefined,
      endDate: contract?.endDate ? new Date(contract.endDate) : undefined,
      reminderEnabled: contract?.reminderEnabled || false,
      sendForSignature: false,
      setReminders: false,
    },
  });
  
  // Update form values when contract data is loaded
  if (contract && !form.formState.isDirty) {
    form.reset({
      name: contract.name,
      type: contract.type,
      status: contract.status,
      description: contract.description || "",
      parties: contract.parties || "",
      templateId: contract.templateId || undefined,
      content: contract.content || "",
      startDate: contract.startDate ? new Date(contract.startDate) : undefined,
      endDate: contract.endDate ? new Date(contract.endDate) : undefined,
      reminderEnabled: contract.reminderEnabled || false,
      sendForSignature: false,
      setReminders: false,
    });
  }
  
  // Create or update contract mutation
  const mutation = useMutation({
    mutationFn: async (values: FormValues) => {
      // Remove form-only fields
      const { sendForSignature, setReminders, ...contractData } = values;
      
      // Update reminderEnabled based on setReminders
      contractData.reminderEnabled = setReminders;
      
      if (contractId) {
        // Update existing contract
        return apiRequest('PUT', `/api/contracts/${contractId}`, contractData);
      } else {
        // Create new contract
        return apiRequest('POST', '/api/contracts', contractData);
      }
    },
    onSuccess: async (data) => {
      // Invalidate and refetch the queries
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['/api/contracts'] }),
        queryClient.invalidateQueries({ queryKey: ['/api/activities'] }),
        queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] })
      ]);

      toast({
        title: contractId ? "Contract updated" : "Contract created",
        description: contractId 
          ? "The contract has been successfully updated." 
          : "The contract has been successfully created.",
        variant: "default",
      });
      
      if (onSuccess) {
        onSuccess();
      } else {
        // Navigate to the contract details page
        navigate(`/contracts/${data.id}`);
      }
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to ${contractId ? 'update' : 'create'} contract: ${error.message}`,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = async (values: FormValues) => {
    try {
      // Remove form-only fields
      const { sendForSignature, setReminders, ...contractData } = values;
      
      // Update reminderEnabled based on setReminders
      contractData.reminderEnabled = setReminders;

      // Convert dates to ISO strings
      if (contractData.startDate instanceof Date) {
        contractData.startDate = contractData.startDate.toISOString();
      }
      if (contractData.endDate instanceof Date) {
        contractData.endDate = contractData.endDate.toISOString();
      }

      // Clean up undefined values
      Object.keys(contractData).forEach(key => {
        if (contractData[key] === undefined) {
          delete contractData[key];
        }
      });

      await mutation.mutateAsync(values);
    } catch (error: any) {
      console.error("Form submission error:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to save contract",
        variant: "destructive",
      });
    }
  };
  
  // Loading state
  if (contractId && isLoadingContract) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Contract Name</FormLabel>
              <FormControl>
                <Input placeholder="Enter contract name" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="type"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Contract Type</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a type" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {contractTypeEnum.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type.charAt(0).toUpperCase() + type.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="status"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Status</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a status" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    {contractStatusEnum.map((status) => (
                      <SelectItem key={status} value={status}>
                        {status.charAt(0).toUpperCase() + status.slice(1)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="templateId"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Template (Optional)</FormLabel>
              <Select 
                onValueChange={(value) => field.onChange(value !== 'none' ? parseInt(value) : undefined)} 
                defaultValue={field.value?.toString() || 'none'}
              >
                <FormControl>
                  <SelectTrigger>
                    <SelectValue placeholder="No template" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="none">No template</SelectItem>
                  {templates.map((template) => (
                    <SelectItem key={template.id} value={template.id.toString()}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="startDate"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Start Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full pl-3 text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="endDate"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>End Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full pl-3 text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      initialFocus
                      disabled={(date) => {
                        const startDate = form.getValues("startDate");
                        return startDate ? date < startDate : false;
                      }}
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        
        <FormField
          control={form.control}
          name="parties"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Parties Involved</FormLabel>
              <FormControl>
                <Input placeholder="Company or individual names" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Enter contract description" 
                  className="resize-none" 
                  rows={3} 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="content"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Contract Content</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Enter contract content or terms" 
                  className="resize-none" 
                  rows={6} 
                  {...field} 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <div className="space-y-3">
          <FormField
            control={form.control}
            name="sendForSignature"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel>Send for signature after creation</FormLabel>
                </div>
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="setReminders"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center space-x-3 space-y-0">
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
                <div className="space-y-1 leading-none">
                  <FormLabel>Set renewal reminders</FormLabel>
                </div>
              </FormItem>
            )}
          />
        </div>
        
        <div className="flex justify-end space-x-3">
          <Button 
            type="button" 
            variant="outline" 
            onClick={onCancel}
          >
            Cancel
          </Button>
          <Button 
            type="submit" 
            disabled={mutation.isPending}
            className="bg-primary hover:bg-primary/90"
          >
            {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            {contractId ? 'Update Contract' : 'Create Contract'}
          </Button>
        </div>
      </form>
    </Form>
  );
}
