import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { Contract } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  Search, 
  Plus, 
  ChevronDown, 
  FileText, 
  Eye, 
  Edit, 
  MoreVertical, 
  Trash2,
  Upload
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Checkbox } from "@/components/ui/checkbox";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ContractTableProps {
  onNewContract?: () => void;
  onImportContract?: () => void;
}

export default function ContractTable({ onNewContract, onImportContract }: ContractTableProps) {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedContracts, setSelectedContracts] = useState<number[]>([]);
  
  // Fetch contracts
  const { data: contracts, isLoading } = useQuery<Contract[]>({
    queryKey: [searchQuery ? `/api/contracts/search?q=${searchQuery}` : '/api/contracts'],
  });
  
  // Handle search input change
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
  };
  
  // Format date for display
  const formatDate = (dateString: string | Date | null) => {
    if (!dateString) return "-";
    const date = typeof dateString === 'string' ? new Date(dateString) : dateString;
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };
  
  // Handle checkbox selection
  const handleSelectContract = (contractId: number, checked: boolean) => {
    if (checked) {
      setSelectedContracts([...selectedContracts, contractId]);
    } else {
      setSelectedContracts(selectedContracts.filter(id => id !== contractId));
    }
  };
  
  // Handle select all
  const handleSelectAll = (checked: boolean) => {
    if (checked && contracts) {
      setSelectedContracts(contracts.map(contract => contract.id));
    } else {
      setSelectedContracts([]);
    }
  };
  
  // Handle delete contract
  const handleDeleteContract = async (contractId: number) => {
    try {
      await apiRequest('DELETE', `/api/contracts/${contractId}`);
      
      // Invalidate cache to refresh data
      queryClient.invalidateQueries({ queryKey: ['/api/contracts'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activities'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      
      toast({
        title: "Contract deleted",
        description: "The contract has been successfully deleted.",
        variant: "default",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete the contract. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="bg-white rounded-lg shadow-sm p-6 card">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
        <h2 className="text-lg font-inter font-semibold mb-4 md:mb-0">Contracts</h2>
        
        <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input 
              placeholder="Search contracts..." 
              className="pl-10 w-full sm:w-64"
              value={searchQuery}
              onChange={handleSearchChange}
            />
          </div>
          
          <div className="flex space-x-2">
            {onImportContract && (
              <Button 
                onClick={onImportContract} 
                variant="outline" 
                className="border-primary text-primary"
              >
                <Upload className="mr-2 h-4 w-4" />
                Import
              </Button>
            )}
            <Button onClick={onNewContract} className="bg-primary hover:bg-primary/90">
              <Plus className="mr-2 h-4 w-4" />
              New Contract
            </Button>
          </div>
        </div>
      </div>
      
      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2 mb-4">
        <span className="text-sm text-gray-500">Filter by:</span>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="h-8 rounded-full">
              <span className="text-xs font-medium">Status: All</span>
              <ChevronDown className="ml-1 h-3 w-3" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem>All</DropdownMenuItem>
            <DropdownMenuItem>Active</DropdownMenuItem>
            <DropdownMenuItem>Pending</DropdownMenuItem>
            <DropdownMenuItem>Expired</DropdownMenuItem>
            <DropdownMenuItem>Draft</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="h-8 rounded-full">
              <span className="text-xs font-medium">Type: All</span>
              <ChevronDown className="ml-1 h-3 w-3" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem>All</DropdownMenuItem>
            <DropdownMenuItem>Service</DropdownMenuItem>
            <DropdownMenuItem>NDA</DropdownMenuItem>
            <DropdownMenuItem>Employment</DropdownMenuItem>
            <DropdownMenuItem>Vendor</DropdownMenuItem>
            <DropdownMenuItem>Other</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm" className="h-8 rounded-full">
              <span className="text-xs font-medium">Date: Last 30 days</span>
              <ChevronDown className="ml-1 h-3 w-3" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem>Last 7 days</DropdownMenuItem>
            <DropdownMenuItem>Last 30 days</DropdownMenuItem>
            <DropdownMenuItem>Last 90 days</DropdownMenuItem>
            <DropdownMenuItem>This year</DropdownMenuItem>
            <DropdownMenuItem>All time</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      
      {/* Table */}
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[40px]">
                <Checkbox 
                  checked={contracts && contracts.length > 0 && selectedContracts.length === contracts.length}
                  onCheckedChange={handleSelectAll}
                />
              </TableHead>
              <TableHead>Contract Name</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Created</TableHead>
              <TableHead>Expires</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              Array(4).fill(0).map((_, index) => (
                <TableRow key={index}>
                  <TableCell><Skeleton className="h-4 w-4" /></TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Skeleton className="h-10 w-10 rounded-lg mr-4" />
                      <div>
                        <Skeleton className="h-4 w-40 mb-1" />
                        <Skeleton className="h-3 w-20" />
                      </div>
                    </div>
                  </TableCell>
                  <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                  <TableCell><Skeleton className="h-5 w-16 rounded-full" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  <TableCell className="text-right"><Skeleton className="h-8 w-20 ml-auto" /></TableCell>
                </TableRow>
              ))
            ) : contracts && contracts.length > 0 ? (
              contracts.map((contract) => (
                <TableRow key={contract.id}>
                  <TableCell>
                    <Checkbox 
                      checked={selectedContracts.includes(contract.id)}
                      onCheckedChange={(checked) => handleSelectContract(contract.id, !!checked)}
                    />
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <div className="flex-shrink-0 h-10 w-10 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center">
                        <FileText className="text-primary h-5 w-5" />
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-foreground">{contract.name}</div>
                        <div className="text-xs text-gray-500">{contract.parties || 'No parties specified'}</div>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="text-sm">{contract.type.charAt(0).toUpperCase() + contract.type.slice(1)}</div>
                  </TableCell>
                  <TableCell>
                    <span className={`status-badge ${contract.status}`}>
                      {contract.status.charAt(0).toUpperCase() + contract.status.slice(1)}
                    </span>
                  </TableCell>
                  <TableCell className="text-sm text-gray-500">
                    {formatDate(contract.createdAt)}
                  </TableCell>
                  <TableCell className="text-sm text-gray-500">
                    {formatDate(contract.endDate)}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end space-x-2">
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => navigate(`/contracts/${contract.id}`)}
                      >
                        <Eye className="h-4 w-4 text-primary" />
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="icon"
                        onClick={() => navigate(`/contracts/${contract.id}?edit=true`)}
                      >
                        <Edit className="h-4 w-4 text-gray-600" />
                      </Button>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <MoreVertical className="h-4 w-4 text-gray-600" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem onClick={() => navigate(`/contracts/${contract.id}`)}>
                            View Details
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => navigate(`/contracts/${contract.id}?edit=true`)}>
                            Edit Contract
                          </DropdownMenuItem>
                          <DropdownMenuItem 
                            className="text-destructive"
                            onClick={() => handleDeleteContract(contract.id)}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete Contract
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8">
                  {searchQuery ? (
                    <div>
                      <p className="text-gray-500">No contracts found matching "{searchQuery}"</p>
                      <Button 
                        variant="link" 
                        className="mt-2 text-primary"
                        onClick={() => setSearchQuery("")}
                      >
                        Clear search
                      </Button>
                    </div>
                  ) : (
                    <div>
                      <p className="text-gray-500">No contracts found</p>
                      <Button 
                        variant="link" 
                        className="mt-2 text-primary"
                        onClick={onNewContract}
                      >
                        Create your first contract
                      </Button>
                    </div>
                  )}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      
      {/* Pagination - only show if we have data */}
      {contracts && contracts.length > 0 && (
        <div className="flex items-center justify-between border-t border-gray-200 px-4 py-3 sm:px-6 mt-4">
          <div className="flex flex-1 justify-between sm:hidden">
            <Button variant="outline" size="sm">Previous</Button>
            <Button variant="outline" size="sm">Next</Button>
          </div>
          <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-700">
                Showing <span className="font-medium">1</span> to <span className="font-medium">{contracts.length}</span> of{" "}
                <span className="font-medium">{contracts.length}</span> results
              </p>
            </div>
            <div>
              <nav className="isolate inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">
                <Button variant="outline" size="icon" className="rounded-l-md">
                  <span className="sr-only">Previous</span>
                  <ChevronDown className="h-4 w-4 rotate-90" />
                </Button>
                <Button variant="outline" className="bg-primary text-white">1</Button>
                <Button variant="outline" size="icon" className="rounded-r-md">
                  <span className="sr-only">Next</span>
                  <ChevronDown className="h-4 w-4 -rotate-90" />
                </Button>
              </nav>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
