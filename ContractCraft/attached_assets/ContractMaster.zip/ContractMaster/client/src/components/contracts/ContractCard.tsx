import React, { useCallback } from "react";
import { Contract } from "@shared/schema";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

interface ContractCardProps {
  contract: Contract;
  onDelete?: (id: number) => void;
}

export function ContractCard({ contract, onDelete }: ContractCardProps) {
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const handleView = () => {
    navigate(`/contracts/${contract.id}`);
  };

  const handleEdit = useCallback(() => {
    navigate(`/contracts/${contract.id}?edit=true`);
  }, [contract.id, navigate]);

  const handleDelete = async () => {
    try {
      if (onDelete) {
        await onDelete(contract.id);
        toast({
          title: "Success",
          description: "Contract deleted successfully",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete contract",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{contract.name}</CardTitle>
        <CardDescription>{contract.type}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid gap-2">
          <div>
            <span className="font-bold">Status: </span>
            <span className="capitalize">{contract.status}</span>
          </div>
          <div>
            <span className="font-bold">Parties: </span>
            {contract.parties}
          </div>
          <div>
            <span className="font-bold">Start Date: </span>
            {contract.startDate ? new Date(contract.startDate).toLocaleDateString() : 'Not set'}
          </div>
          {contract.endDate && (
            <div>
              <span className="font-bold">End Date: </span>
              {new Date(contract.endDate).toLocaleDateString()}
            </div>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={handleView}>
          View
        </Button>
        <Button variant="outline" onClick={handleEdit}>
          Edit
        </Button>
        <Button variant="destructive" onClick={handleDelete}>
          Delete
        </Button>
      </CardFooter>
    </Card>
  );
}