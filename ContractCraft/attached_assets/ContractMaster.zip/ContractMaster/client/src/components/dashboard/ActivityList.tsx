import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Activity } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  FileText, 
  Edit, 
  CheckCircle, 
  Send, 
  Trash,
  Eye, 
  Download,
  Upload
} from "lucide-react";

interface ActivityListProps {
  limit?: number;
}

export default function ActivityList({ limit = 4 }: ActivityListProps) {
  const { data: activities, isLoading } = useQuery<Activity[]>({ 
    queryKey: [`/api/activities?limit=${limit}`] 
  });
  
  // Function to get icon based on activity type
  const getActivityIcon = (type: string) => {
    switch (type) {
      case "create":
        return <FileText className="text-primary text-sm" />;
      case "update":
        return <Edit className="text-primary text-sm" />;
      case "sign":
        return <CheckCircle className="text-success text-sm" />;
      case "send":
        return <Send className="text-warning text-sm" />;
      case "delete":
        return <Trash className="text-destructive text-sm" />;
      case "view":
        return <Eye className="text-primary text-sm" />;
      case "export":
        return <Download className="text-primary text-sm" />;
      case "import":
        return <Upload className="text-primary text-sm" />;
      default:
        return <FileText className="text-primary text-sm" />;
    }
  };
  
  // Function to get background color based on activity type
  const getActivityBgColor = (type: string) => {
    switch (type) {
      case "create":
        return "bg-primary bg-opacity-10";
      case "update":
        return "bg-primary bg-opacity-10";
      case "sign":
        return "bg-success bg-opacity-10";
      case "send":
        return "bg-warning bg-opacity-10";
      case "delete":
        return "bg-destructive bg-opacity-10";
      case "view":
        return "bg-primary bg-opacity-10";
      case "export":
        return "bg-primary bg-opacity-10";
      case "import":
        return "bg-primary bg-opacity-10";
      default:
        return "bg-primary bg-opacity-10";
    }
  };
  
  // Function to format time ago
  const getTimeAgo = (timestamp: string) => {
    const now = new Date();
    const activityTime = new Date(timestamp);
    const diffMs = now.getTime() - activityTime.getTime();
    const diffMins = Math.round(diffMs / 60000);
    const diffHours = Math.round(diffMs / 3600000);
    const diffDays = Math.round(diffMs / 86400000);
    
    if (diffMins < 60) {
      return `${diffMins} minute${diffMins !== 1 ? 's' : ''} ago`;
    } else if (diffHours < 24) {
      return `${diffHours} hour${diffHours !== 1 ? 's' : ''} ago`;
    } else {
      return `${diffDays} day${diffDays !== 1 ? 's' : ''} ago`;
    }
  };
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array(limit).fill(0).map((_, index) => (
          <div key={index} className="flex items-start">
            <Skeleton className="w-8 h-8 rounded-full mr-3 mt-1" />
            <div className="flex-1">
              <Skeleton className="h-4 w-full max-w-[250px] mb-2" />
              <Skeleton className="h-3 w-24" />
            </div>
          </div>
        ))}
      </div>
    );
  }
  
  if (!activities || activities.length === 0) {
    return (
      <div className="text-center py-6">
        <p className="text-gray-500">No activity yet</p>
      </div>
    );
  }
  
  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-start">
          <div className={`w-8 h-8 rounded-full ${getActivityBgColor(activity.type)} flex items-center justify-center mr-3 mt-1`}>
            {getActivityIcon(activity.type)}
          </div>
          <div>
            <p className="text-sm font-medium">{activity.description}</p>
            <p className="text-xs text-gray-500">{getTimeAgo(activity.createdAt.toString())}</p>
          </div>
        </div>
      ))}
      
      <Button variant="ghost" size="sm" className="w-full text-primary">
        View All Activity
      </Button>
    </div>
  );
}
