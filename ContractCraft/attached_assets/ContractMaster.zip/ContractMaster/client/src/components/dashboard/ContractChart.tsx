import { Card, CardContent } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend
} from "recharts";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { Contract } from "@shared/schema";

// Helper to group contracts by months
const groupContractsByMonth = (contracts: Contract[], months: number = 6) => {
  const now = new Date();
  const data = [];
  
  // Create empty data structure for the last n months
  for (let i = months - 1; i >= 0; i--) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
    data.push({
      month: date.toLocaleString('default', { month: 'short' }),
      active: 0,
      pending: 0,
      expired: 0,
      total: 0
    });
  }
  
  // Fill with actual contract data
  contracts.forEach(contract => {
    const createdAt = new Date(contract.createdAt);
    const monthName = createdAt.toLocaleString('default', { month: 'short' });
    
    const monthIndex = data.findIndex(d => d.month === monthName);
    if (monthIndex !== -1) {
      data[monthIndex].total += 1;
      
      switch (contract.status) {
        case 'active':
          data[monthIndex].active += 1;
          break;
        case 'pending':
          data[monthIndex].pending += 1;
          break;
        case 'expired':
          data[monthIndex].expired += 1;
          break;
      }
    }
  });
  
  return data;
};

export default function ContractChart() {
  const [timePeriod, setTimePeriod] = useState<'monthly' | 'quarterly' | 'yearly'>('monthly');
  const { data: contracts, isLoading } = useQuery<Contract[]>({ 
    queryKey: ['/api/contracts'] 
  });
  
  const getChartData = () => {
    if (!contracts) return [];
    
    switch (timePeriod) {
      case 'monthly':
        return groupContractsByMonth(contracts, 6);
      case 'quarterly':
        return groupContractsByMonth(contracts, 12);
      case 'yearly':
        return groupContractsByMonth(contracts, 24);
      default:
        return groupContractsByMonth(contracts, 6);
    }
  };
  
  return (
    <Card className="card-hover">
      <CardContent className="p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-lg font-inter font-semibold">Contract Status Overview</h2>
          <div className="flex space-x-2">
            <Button 
              variant={timePeriod === 'monthly' ? 'default' : 'ghost'} 
              size="sm"
              onClick={() => setTimePeriod('monthly')}
              className={timePeriod === 'monthly' ? 'bg-primary text-white' : 'text-gray-500'}
            >
              Monthly
            </Button>
            <Button 
              variant={timePeriod === 'quarterly' ? 'default' : 'ghost'} 
              size="sm"
              onClick={() => setTimePeriod('quarterly')}
              className={timePeriod === 'quarterly' ? 'bg-primary text-white' : 'text-gray-500'}
            >
              Quarterly
            </Button>
            <Button 
              variant={timePeriod === 'yearly' ? 'default' : 'ghost'} 
              size="sm"
              onClick={() => setTimePeriod('yearly')}
              className={timePeriod === 'yearly' ? 'bg-primary text-white' : 'text-gray-500'}
            >
              Yearly
            </Button>
          </div>
        </div>
        
        {isLoading ? (
          <Skeleton className="h-64 w-full" />
        ) : (
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart
                data={getChartData()}
                margin={{ top: 10, right: 30, left: 0, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Area 
                  type="monotone" 
                  dataKey="active" 
                  stackId="1" 
                  stroke="hsl(var(--success))" 
                  fill="hsl(var(--success))" 
                  fillOpacity={0.6}
                />
                <Area 
                  type="monotone" 
                  dataKey="pending" 
                  stackId="1" 
                  stroke="hsl(var(--warning))" 
                  fill="hsl(var(--warning))" 
                  fillOpacity={0.6}
                />
                <Area 
                  type="monotone" 
                  dataKey="expired" 
                  stackId="1" 
                  stroke="hsl(var(--destructive))" 
                  fill="hsl(var(--destructive))" 
                  fillOpacity={0.6}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
