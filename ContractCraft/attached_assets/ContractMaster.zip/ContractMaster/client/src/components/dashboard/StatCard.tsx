import { Card, CardContent } from "@/components/ui/card";
import { 
  FileText, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  TrendingUp,
  TrendingDown,
  AlertTriangle
} from "lucide-react";

interface StatCardProps {
  title: string;
  value: number;
  type: "total" | "active" | "pending" | "expiring";
  changeValue?: number | null;
  changeText?: string;
}

export default function StatCard({ title, value, type, changeValue, changeText }: StatCardProps) {
  // Determine icon and color based on type
  const getIconConfig = () => {
    switch (type) {
      case "total":
        return { 
          icon: <FileText className="text-primary" />, 
          bgColor: "bg-primary bg-opacity-10" 
        };
      case "active":
        return { 
          icon: <CheckCircle2 className="text-success" />, 
          bgColor: "bg-success bg-opacity-10" 
        };
      case "pending":
        return { 
          icon: <Clock className="text-warning" />, 
          bgColor: "bg-warning bg-opacity-10" 
        };
      case "expiring":
        return { 
          icon: <AlertCircle className="text-destructive" />, 
          bgColor: "bg-destructive bg-opacity-10" 
        };
      default:
        return { 
          icon: <FileText className="text-primary" />, 
          bgColor: "bg-primary bg-opacity-10" 
        };
    }
  };
  
  const { icon, bgColor } = getIconConfig();
  
  // Determine trend indicator
  const getTrendIndicator = () => {
    if (changeValue === null || changeValue === undefined) {
      return null;
    }
    
    if (type === "expiring") {
      // For expiring contracts, more is bad
      return changeValue > 0 
        ? <AlertTriangle className="text-sm mr-1 text-warning" /> 
        : <TrendingDown className="text-sm mr-1 text-success" />;
    }
    
    // For other stats, more is good
    return changeValue > 0 
      ? <TrendingUp className="text-sm mr-1 text-success" /> 
      : <TrendingDown className="text-sm mr-1 text-destructive" />;
  };
  
  return (
    <Card className="card-hover">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-sm text-gray-500 font-medium">{title}</p>
            <p className="text-3xl font-inter font-semibold mt-1">{value}</p>
          </div>
          <div className={`w-10 h-10 rounded-full ${bgColor} flex items-center justify-center`}>
            {icon}
          </div>
        </div>
        
        {(changeValue !== null && changeValue !== undefined) && (
          <div className={`mt-4 flex items-center text-sm ${
            type === "expiring" 
              ? (changeValue > 0 ? "text-warning" : "text-success")
              : (changeValue > 0 ? "text-success" : "text-destructive")
          }`}>
            {getTrendIndicator()}
            <span>{changeText || `${Math.abs(changeValue)}% from last month`}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
