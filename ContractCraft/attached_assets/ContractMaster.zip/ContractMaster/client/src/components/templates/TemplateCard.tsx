import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Template } from "@shared/schema";
import { Copy, Eye, Edit, Trash2, FileText } from "lucide-react";
import { format } from "date-fns";
import { 
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";

interface TemplateCardProps {
  template: Template;
  onView?: (template: Template) => void;
  onEdit?: (template: Template) => void;
  onDelete?: (id: number) => void;
  onUseTemplate?: (template: Template) => void;
}

export default function TemplateCard({ 
  template, 
  onView, 
  onEdit, 
  onDelete,
  onUseTemplate
}: TemplateCardProps) {
  
  // Format date for display
  const formatDate = (dateString: string) => {
    return format(new Date(dateString), "MMM d, yyyy");
  };
  
  // Truncate description for preview
  const truncateText = (text: string | null, maxLength: number = 100) => {
    if (!text) return "No description provided";
    return text.length > maxLength 
      ? text.substring(0, maxLength) + "..." 
      : text;
  };
  
  return (
    <Card className="card-hover h-full flex flex-col">
      <CardContent className="flex-1 p-6">
        <div className="flex justify-between items-start mb-3">
          <div className="flex-shrink-0 h-10 w-10 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center mr-3">
            <Copy className="text-primary h-5 w-5" />
          </div>
          {template.isPublic && (
            <Badge variant="outline" className="bg-primary/10 text-primary border-primary">
              Public
            </Badge>
          )}
        </div>
        
        <h3 className="text-lg font-medium mb-2">{template.name}</h3>
        
        <p className="text-sm text-gray-500 mb-4">
          {truncateText(template.description, 120)}
        </p>
        
        <div className="space-y-2 mt-auto">
          <div className="flex items-center text-sm">
            <span className="font-medium mr-2">Type:</span>
            <span>{template.type.charAt(0).toUpperCase() + template.type.slice(1)}</span>
          </div>
          
          <div className="flex items-center text-sm">
            <FileText className="mr-2 h-4 w-4 text-gray-400" />
            <span className="font-medium mr-2">Created:</span>
            <span>{formatDate(template.createdAt as string)}</span>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="flex justify-between px-6 py-4 border-t">
        <Button 
          variant="outline" 
          size="sm"
          onClick={() => onView && onView(template)}
        >
          <Eye className="mr-2 h-4 w-4" />
          View
        </Button>
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="sm">
              More
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => onUseTemplate && onUseTemplate(template)}>
              <FileText className="mr-2 h-4 w-4" />
              Use Template
            </DropdownMenuItem>
            {!template.isPublic && (
              <>
                <DropdownMenuItem onClick={() => onEdit && onEdit(template)}>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  className="text-destructive focus:text-destructive" 
                  onClick={() => onDelete && onDelete(template.id)}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>
              </>
            )}
          </DropdownMenuContent>
        </DropdownMenu>
      </CardFooter>
    </Card>
  );
}
