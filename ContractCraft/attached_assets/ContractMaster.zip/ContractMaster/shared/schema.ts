import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  date,
  boolean,
  integer,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const usersRelations = relations(users, ({ many }) => ({
  contracts: many(contracts),
  templates: many(templates),
  activities: many(activities),
}));

// Contract types enum
export const contractTypeEnum = [
  "service",
  "nda",
  "employment",
  "vendor",
  "partnership",
  "other",
] as const;

// Contract status enum
export const contractStatusEnum = [
  "draft",
  "pending",
  "active",
  "expired",
  "terminated",
  "archived",
] as const;

// Contracts table
export const contracts = pgTable("contracts", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  type: varchar("type", { enum: contractTypeEnum }).notNull(),
  status: varchar("status", { enum: contractStatusEnum }).notNull().default("draft"),
  description: text("description"),
  parties: text("parties"),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  templateId: integer("template_id").references(() => templates.id),
  content: text("content"),
  filePath: text("file_path"),
  startDate: date("start_date"),
  endDate: date("end_date"),
  reminderEnabled: boolean("reminder_enabled").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const contractsRelations = relations(contracts, ({ one, many }) => ({
  user: one(users, {
    fields: [contracts.userId],
    references: [users.id],
  }),
  template: one(templates, {
    fields: [contracts.templateId],
    references: [templates.id],
  }),
  activities: many(activities),
}));

// Templates table
export const templates = pgTable("templates", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  type: varchar("type", { enum: contractTypeEnum }).notNull(),
  description: text("description"),
  content: text("content").notNull(),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  isPublic: boolean("is_public").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const templatesRelations = relations(templates, ({ one, many }) => ({
  user: one(users, {
    fields: [templates.userId],
    references: [users.id],
  }),
  contracts: many(contracts),
}));

// Activity types enum
export const activityTypeEnum = [
  "create",
  "update",
  "delete",
  "sign",
  "send",
  "view",
  "export",
  "import",
] as const;

// Activities table for tracking user actions
export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  type: varchar("type", { enum: activityTypeEnum }).notNull(),
  description: text("description").notNull(),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }).notNull(),
  contractId: integer("contract_id").references(() => contracts.id, { onDelete: 'cascade' }),
  createdAt: timestamp("created_at").defaultNow(),
});

export const activitiesRelations = relations(activities, ({ one }) => ({
  user: one(users, {
    fields: [activities.userId],
    references: [users.id],
  }),
  contract: one(contracts, {
    fields: [activities.contractId],
    references: [contracts.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users);
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;

export const insertContractSchema = createInsertSchema(contracts).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});
export type InsertContract = z.infer<typeof insertContractSchema>;
export type Contract = typeof contracts.$inferSelect;

export const insertTemplateSchema = createInsertSchema(templates).omit({ 
  id: true, 
  createdAt: true, 
  updatedAt: true 
});
export type InsertTemplate = z.infer<typeof insertTemplateSchema>;
export type Template = typeof templates.$inferSelect;

export const insertActivitySchema = createInsertSchema(activities).omit({ 
  id: true, 
  createdAt: true 
});
export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;
