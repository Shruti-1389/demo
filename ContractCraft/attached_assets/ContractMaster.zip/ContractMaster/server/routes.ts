import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertContractSchema, insertTemplateSchema, insertActivitySchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";
import { ZodError } from "zod";

// Configure multer for file uploads
const upload = multer({
  storage: multer.diskStorage({
    destination: function (req, file, cb) {
      const uploadDir = path.join(process.cwd(), "uploads");
      // Create directory if it doesn't exist
      if (!fs.existsSync(uploadDir)) {
        fs.mkdirSync(uploadDir, { recursive: true });
      }
      cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
      const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname));
    },
  }),
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
});

// Error handling middleware
const handleErrors = (err: any, req: Request, res: Response) => {
  console.error("API Error:", err);
  
  if (err instanceof ZodError) {
    return res.status(400).json({
      message: "Validation error",
      errors: err.errors,
    });
  }
  
  const statusCode = err.statusCode || 500;
  const message = err.message || "Internal Server Error";
  return res.status(statusCode).json({ message });
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth route
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  // Contract routes
  app.get('/api/contracts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const contracts = await storage.getContractsByUser(userId);
      res.json(contracts);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  app.get('/api/contracts/search', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const query = req.query.q as string || '';
      const contracts = await storage.searchContracts(userId, query);
      res.json(contracts);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  app.get('/api/contracts/status/:status', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const status = req.params.status;
      const contracts = await storage.getContractsByStatus(userId, status);
      res.json(contracts);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  app.get('/api/contracts/expiring', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const days = parseInt(req.query.days as string) || 30;
      const contracts = await storage.getExpiringContracts(userId, days);
      res.json(contracts);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  app.get('/api/contracts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const contractId = parseInt(req.params.id);
      if (isNaN(contractId)) {
        return res.status(400).json({ message: "Invalid contract ID" });
      }
      const contract = await storage.getContract(contractId);
      
      if (!contract) {
        return res.status(404).json({ message: "Contract not found" });
      }
      
      if (contract.userId !== req.user.claims.sub) {
        return res.status(403).json({ message: "You don't have permission to access this contract" });
      }
      
      res.json(contract);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  app.post('/api/contracts', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const contractData = insertContractSchema.parse({
        ...req.body,
        userId,
      });
      
      const newContract = await storage.createContract(contractData);
      
      // Log activity
      await storage.createActivity({
        type: "create",
        description: `Created contract: ${newContract.name}`,
        userId,
        contractId: newContract.id,
      });
      
      res.status(201).json(newContract);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  app.put('/api/contracts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const contractId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check if contract exists and belongs to user
      const existingContract = await storage.getContract(contractId);
      if (!existingContract) {
        return res.status(404).json({ message: "Contract not found" });
      }
      
      if (existingContract.userId !== userId) {
        return res.status(403).json({ message: "You don't have permission to update this contract" });
      }
      
      const updatedContract = await storage.updateContract(contractId, req.body);
      
      // Log activity
      await storage.createActivity({
        type: "update",
        description: `Updated contract: ${existingContract.name}`,
        userId,
        contractId,
      });
      
      res.json(updatedContract);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  app.delete('/api/contracts/:id', isAuthenticated, async (req: any, res) => {
    try {
      const contractId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check if contract exists and belongs to user
      const existingContract = await storage.getContract(contractId);
      if (!existingContract) {
        return res.status(404).json({ message: "Contract not found" });
      }
      
      if (existingContract.userId !== userId) {
        return res.status(403).json({ message: "You don't have permission to delete this contract" });
      }
      
      const contractName = existingContract.name;
      const deleted = await storage.deleteContract(contractId);
      
      if (deleted) {
        // Log activity
        await storage.createActivity({
          type: "delete",
          description: `Deleted contract: ${contractName}`,
          userId,
          contractId: null,
        });
      }
      
      res.json({ success: deleted });
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  // File upload for contracts
  app.post('/api/contracts/:id/upload', isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      const contractId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check if contract exists and belongs to user
      const existingContract = await storage.getContract(contractId);
      if (!existingContract) {
        return res.status(404).json({ message: "Contract not found" });
      }
      
      if (existingContract.userId !== userId) {
        return res.status(403).json({ message: "You don't have permission to update this contract" });
      }
      
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      const filePath = req.file.path;
      const updatedContract = await storage.updateContract(contractId, { filePath });
      
      // Log activity
      await storage.createActivity({
        type: "update",
        description: `Uploaded file for contract: ${existingContract.name}`,
        userId,
        contractId,
      });
      
      res.json(updatedContract);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });
  
  // Import contract from PDF/Word
  app.post('/api/contracts/import', isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      // Get file extension
      const fileExt = path.extname(req.file.originalname).toLowerCase();
      
      // Check if file is PDF or Word document
      if (fileExt !== '.pdf' && fileExt !== '.doc' && fileExt !== '.docx') {
        return res.status(400).json({ 
          message: "Invalid file format. Only PDF and Word documents are supported." 
        });
      }
      
      const filePath = req.file.path;
      const fileName = path.basename(req.file.originalname, fileExt);
      
      // Create a new contract with the imported file
      const contractData = {
        name: fileName || "Imported Contract",
        description: `Imported from ${fileExt.substring(1).toUpperCase()} file`,
        userId,
        status: "draft" as const,
        type: "other" as const,
        filePath,
        startDate: new Date().toISOString(),
        parties: "Imported Document",
      };
      
      const newContract = await storage.createContract(contractData);
      
      // Log activity
      await storage.createActivity({
        type: "create",
        description: `Imported contract from file: ${fileName}${fileExt}`,
        userId,
        contractId: newContract.id,
      });
      
      res.status(201).json(newContract);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  // Template routes
  app.get('/api/templates', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userTemplates = await storage.getTemplatesByUser(userId);
      const publicTemplates = await storage.getPublicTemplates();
      
      // Filter out duplicates (user's templates that are also public)
      const userTemplateIds = new Set(userTemplates.map(t => t.id));
      const filteredPublicTemplates = publicTemplates.filter(t => !userTemplateIds.has(t.id));
      
      res.json({
        userTemplates,
        publicTemplates: filteredPublicTemplates
      });
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  app.get('/api/templates/:id', isAuthenticated, async (req: any, res) => {
    try {
      const templateId = parseInt(req.params.id);
      const template = await storage.getTemplate(templateId);
      
      if (!template) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      if (!template.isPublic && template.userId !== req.user.claims.sub) {
        return res.status(403).json({ message: "You don't have permission to access this template" });
      }
      
      res.json(template);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  app.post('/api/templates', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const templateData = insertTemplateSchema.parse({
        ...req.body,
        userId,
      });
      
      const newTemplate = await storage.createTemplate(templateData);
      
      // Log activity
      await storage.createActivity({
        type: "create",
        description: `Created template: ${newTemplate.name}`,
        userId,
        contractId: null,
      });
      
      res.status(201).json(newTemplate);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  app.put('/api/templates/:id', isAuthenticated, async (req: any, res) => {
    try {
      const templateId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check if template exists and belongs to user
      const existingTemplate = await storage.getTemplate(templateId);
      if (!existingTemplate) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      if (existingTemplate.userId !== userId) {
        return res.status(403).json({ message: "You don't have permission to update this template" });
      }
      
      const updatedTemplate = await storage.updateTemplate(templateId, req.body);
      
      // Log activity
      await storage.createActivity({
        type: "update",
        description: `Updated template: ${existingTemplate.name}`,
        userId,
        contractId: null,
      });
      
      res.json(updatedTemplate);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  app.delete('/api/templates/:id', isAuthenticated, async (req: any, res) => {
    try {
      const templateId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check if template exists and belongs to user
      const existingTemplate = await storage.getTemplate(templateId);
      if (!existingTemplate) {
        return res.status(404).json({ message: "Template not found" });
      }
      
      if (existingTemplate.userId !== userId) {
        return res.status(403).json({ message: "You don't have permission to delete this template" });
      }
      
      const templateName = existingTemplate.name;
      const deleted = await storage.deleteTemplate(templateId);
      
      if (deleted) {
        // Log activity
        await storage.createActivity({
          type: "delete",
          description: `Deleted template: ${templateName}`,
          userId,
          contractId: null,
        });
      }
      
      res.json({ success: deleted });
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  // Activity routes
  app.get('/api/activities', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const limit = parseInt(req.query.limit as string) || 10;
      const activities = await storage.getActivitiesByUser(userId, limit);
      res.json(activities);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  app.get('/api/contracts/:id/activities', isAuthenticated, async (req: any, res) => {
    try {
      const contractId = parseInt(req.params.id);
      const userId = req.user.claims.sub;
      
      // Check if contract exists and belongs to user
      const existingContract = await storage.getContract(contractId);
      if (!existingContract) {
        return res.status(404).json({ message: "Contract not found" });
      }
      
      if (existingContract.userId !== userId) {
        return res.status(403).json({ message: "You don't have permission to view activities for this contract" });
      }
      
      const limit = parseInt(req.query.limit as string) || 10;
      const activities = await storage.getActivitiesByContract(contractId, limit);
      res.json(activities);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  // Dashboard stats
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const stats = await storage.getContractStats(userId);
      res.json(stats);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  const httpServer = createServer(app);
  // Export contracts to Excel
  app.get('/api/contracts/export', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      if (!userId) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      const contracts = await storage.getContractsByUser(userId);
      
      const XLSX = require('xlsx');
      const workbook = XLSX.utils.book_new();
      
      // Convert contracts to worksheet data
      const wsData = contracts.map(contract => ({
        'Contract Name': contract.name,
        'Type': contract.type,
        'Status': contract.status,
        'Parties': contract.parties,
        'Start Date': contract.startDate,
        'End Date': contract.endDate,
        'Description': contract.description,
      }));
      
      const ws = XLSX.utils.json_to_sheet(wsData);
      XLSX.utils.book_append_sheet(workbook, ws, "Contracts");
      
      // Generate buffer
      const buf = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
      
      // Send response
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', 'attachment; filename=contracts.xlsx');
      res.send(buf);
    } catch (error) {
      handleErrors(error, req, res);
    }
  });

  return httpServer;
}
