import {
  users,
  contracts,
  templates,
  activities,
  type User,
  type UpsertUser,
  type Contract,
  type InsertContract,
  type Template,
  type InsertTemplate,
  type Activity,
  type InsertActivity,
} from "@shared/schema";
import { db } from "./db";
import { and, desc, eq, gt, gte, ilike, lt, lte, sql } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Contract operations
  createContract(contract: InsertContract): Promise<Contract>;
  getContract(id: number): Promise<Contract | undefined>;
  getContractsByUser(userId: string): Promise<Contract[]>;
  updateContract(id: number, contract: Partial<InsertContract>): Promise<Contract | undefined>;
  deleteContract(id: number): Promise<boolean>;
  searchContracts(userId: string, query: string): Promise<Contract[]>;
  getContractsByStatus(userId: string, status: string): Promise<Contract[]>;
  getExpiringContracts(userId: string, days: number): Promise<Contract[]>;
  
  // Template operations
  createTemplate(template: InsertTemplate): Promise<Template>;
  getTemplate(id: number): Promise<Template | undefined>;
  getTemplatesByUser(userId: string): Promise<Template[]>;
  getPublicTemplates(): Promise<Template[]>;
  updateTemplate(id: number, template: Partial<InsertTemplate>): Promise<Template | undefined>;
  deleteTemplate(id: number): Promise<boolean>;
  
  // Activity operations
  createActivity(activity: InsertActivity): Promise<Activity>;
  getActivitiesByUser(userId: string, limit?: number): Promise<Activity[]>;
  getActivitiesByContract(contractId: number, limit?: number): Promise<Activity[]>;
  
  // Dashboard stats
  getContractStats(userId: string): Promise<{ total: number, active: number, pending: number, expiring: number }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }
  
  // Contract operations
  async createContract(contract: InsertContract): Promise<Contract> {
    const [newContract] = await db
      .insert(contracts)
      .values(contract)
      .returning();
    return newContract;
  }
  
  async getContract(id: number): Promise<Contract | undefined> {
    const [contract] = await db
      .select()
      .from(contracts)
      .where(eq(contracts.id, id));
    return contract;
  }
  
  async getContractsByUser(userId: string): Promise<Contract[]> {
    return await db
      .select()
      .from(contracts)
      .where(eq(contracts.userId, userId))
      .orderBy(desc(contracts.createdAt));
  }
  
  async updateContract(id: number, contractData: Partial<InsertContract>): Promise<Contract | undefined> {
    const [updatedContract] = await db
      .update(contracts)
      .set({
        ...contractData,
        updatedAt: new Date(),
      })
      .where(eq(contracts.id, id))
      .returning();
    return updatedContract;
  }
  
  async deleteContract(id: number): Promise<boolean> {
    const [deleted] = await db
      .delete(contracts)
      .where(eq(contracts.id, id))
      .returning();
    return !!deleted;
  }
  
  async searchContracts(userId: string, query: string): Promise<Contract[]> {
    return await db
      .select()
      .from(contracts)
      .where(and(
        eq(contracts.userId, userId),
        ilike(contracts.name, `%${query}%`)
      ))
      .orderBy(desc(contracts.createdAt));
  }
  
  async getContractsByStatus(userId: string, status: string): Promise<Contract[]> {
    return await db
      .select()
      .from(contracts)
      .where(and(
        eq(contracts.userId, userId),
        eq(contracts.status, status)
      ))
      .orderBy(desc(contracts.createdAt));
  }
  
  async getExpiringContracts(userId: string, days: number): Promise<Contract[]> {
    const today = new Date();
    const future = new Date();
    future.setDate(today.getDate() + days);
    
    return await db
      .select()
      .from(contracts)
      .where(and(
        eq(contracts.userId, userId),
        eq(contracts.status, 'active'),
        lte(contracts.endDate, future),
        gt(contracts.endDate, today)
      ))
      .orderBy(contracts.endDate);
  }
  
  // Template operations
  async createTemplate(template: InsertTemplate): Promise<Template> {
    const [newTemplate] = await db
      .insert(templates)
      .values(template)
      .returning();
    return newTemplate;
  }
  
  async getTemplate(id: number): Promise<Template | undefined> {
    const [template] = await db
      .select()
      .from(templates)
      .where(eq(templates.id, id));
    return template;
  }
  
  async getTemplatesByUser(userId: string): Promise<Template[]> {
    return await db
      .select()
      .from(templates)
      .where(eq(templates.userId, userId))
      .orderBy(desc(templates.createdAt));
  }
  
  async getPublicTemplates(): Promise<Template[]> {
    return await db
      .select()
      .from(templates)
      .where(eq(templates.isPublic, true))
      .orderBy(desc(templates.createdAt));
  }
  
  async updateTemplate(id: number, templateData: Partial<InsertTemplate>): Promise<Template | undefined> {
    const [updatedTemplate] = await db
      .update(templates)
      .set({
        ...templateData,
        updatedAt: new Date(),
      })
      .where(eq(templates.id, id))
      .returning();
    return updatedTemplate;
  }
  
  async deleteTemplate(id: number): Promise<boolean> {
    const [deleted] = await db
      .delete(templates)
      .where(eq(templates.id, id))
      .returning();
    return !!deleted;
  }
  
  // Activity operations
  async createActivity(activity: InsertActivity): Promise<Activity> {
    const [newActivity] = await db
      .insert(activities)
      .values(activity)
      .returning();
    return newActivity;
  }
  
  async getActivitiesByUser(userId: string, limit: number = 5): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .where(eq(activities.userId, userId))
      .orderBy(desc(activities.createdAt))
      .limit(limit);
  }
  
  async getActivitiesByContract(contractId: number, limit: number = 10): Promise<Activity[]> {
    return await db
      .select()
      .from(activities)
      .where(eq(activities.contractId, contractId))
      .orderBy(desc(activities.createdAt))
      .limit(limit);
  }
  
  // Dashboard stats
  async getContractStats(userId: string): Promise<{ total: number, active: number, pending: number, expiring: number }> {
    const total = await db
      .select({ count: sql<number>`count(*)` })
      .from(contracts)
      .where(eq(contracts.userId, userId));
    
    const active = await db
      .select({ count: sql<number>`count(*)` })
      .from(contracts)
      .where(and(
        eq(contracts.userId, userId),
        eq(contracts.status, 'active')
      ));
    
    const pending = await db
      .select({ count: sql<number>`count(*)` })
      .from(contracts)
      .where(and(
        eq(contracts.userId, userId),
        eq(contracts.status, 'pending')
      ));
    
    const today = new Date();
    const thirtyDaysLater = new Date();
    thirtyDaysLater.setDate(today.getDate() + 30);
    
    const expiring = await db
      .select({ count: sql<number>`count(*)` })
      .from(contracts)
      .where(and(
        eq(contracts.userId, userId),
        eq(contracts.status, 'active'),
        lte(contracts.endDate, thirtyDaysLater),
        gt(contracts.endDate, today)
      ));
    
    return {
      total: total[0]?.count || 0,
      active: active[0]?.count || 0,
      pending: pending[0]?.count || 0,
      expiring: expiring[0]?.count || 0,
    };
  }
}

export const storage = new DatabaseStorage();
